package edu.csc.foodnow;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TabLayout tabLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tabLayout = findViewById(R.id.tabLayout);
        createTabs();
    }

    private void createTabs() {
        TextView tabHome = (TextView) LayoutInflater.from(this).inflate(R.layout.layout_custom_tab, null);
        tabHome.setText(getString(R.string.text_home));
        tabHome.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.icon_home, 0, 0);
        tabLayout.addTab(tabLayout.newTab());
        tabLayout.getTabAt(0).setCustomView(tabHome);

        TextView tabOrder = (TextView) LayoutInflater.from(this).inflate(R.layout.layout_custom_tab, null);
        tabOrder.setText(getString(R.string.text_order));
        tabOrder.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.icon_order, 0, 0);
        tabLayout.addTab(tabLayout.newTab());
        tabLayout.getTabAt(1).setCustomView(tabOrder);

        TextView tabProfile = (TextView) LayoutInflater.from(this).inflate(R.layout.layout_custom_tab, null);
        tabProfile.setText(getString(R.string.text_profile));
        tabProfile.setCompoundDrawablesWithIntrinsicBounds(0, R.drawable.icon_profile, 0, 0);
        tabLayout.addTab(tabLayout.newTab());
        tabLayout.getTabAt(2).setCustomView(tabProfile);
    }
}
