package edu.csc.foodnow;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class RestaurantActivity extends AppCompatActivity implements FoodAdapter.OnFoodItemClickListener {
    RecyclerView rvFoods;
    Restaurant restaurant;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant);

        restaurant = new Restaurant("7 Eleven", R.drawable.ic_seveneleven, R.drawable.cover_menu_1, "82 Nguyen Thi Minh Khai, Phuong 6, Quan 3", "6:00 - 23:00");
        ArrayList<Food> foods = Food.getMockData();
        restaurant.setMenu(foods);
        rvFoods = findViewById(R.id.rvFoods);
    }

    @Override
    public void onFoodItemClick(Food food) {

    }
}
